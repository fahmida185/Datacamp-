#
# SciNet's DAT112, Neural Network Programming.
# Lecture 6, 3 May 2018.
# Erik Spence.
#
# This file, firstsession.py, contains a script which implements our
# first script-based TensorFlow session.


##############################################################


from __future__ import print_function
import tensorflow as tf

# Define the constants.
y = tf.constant([1, 2, 3])
z = tf.constant(range(3, 6))

# Define the operation, and put it in a variable.
answer = y * z

# Open the TensorFlow session.
sess = tf.Session()

# Run the result.
result = sess.run(answer)

# Print the result.
print(result)

# Close the session.
sess.close()

